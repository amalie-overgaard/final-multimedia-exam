<!doctype html>
<html lang="da">
  <head>
  <script src="https://www.gstatic.com/firebasejs/5.0.4/firebase.js"></script>
<script>
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyCq4E6zD9Krz4EQRSRUqMyTNLp7L79lS6w",
    authDomain: "wiine-90630.firebaseapp.com",
    databaseURL: "https://wiine-90630.firebaseio.com",
    projectId: "wiine-90630",
    storageBucket: "",
    messagingSenderId: "594374930367"
  };
  firebase.initializeApp(config);
</script>
  <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Wiine - Eksamensprojekt</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">

    <!-- Custom style -->
    <link href="css/style.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">

  </head>
  <body>
    <!-- Navbar -->
  <nav class="navbar  navbar-light bg-faded">
  <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <a class="navbar-brand" href="index.php">
    <img src="img/Logo.png">
  </a>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
        <a class="nav-link" href="#vision">Vision</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#rose">Rose</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#glas">Glas</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#kontakt">Kontakt</a>
      </li>
    </ul>
  </div>
</nav>

    <!-- Jumbotron -->
    <section class="intro">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <h1>Verdens hyggeligste vinklub.</h1>
            </div>
        </div>
            </div>
    </section>

    <!-- Vision -->
    <section class="vision" id="vision">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-6 txt-area">
            <h1>Vores vision</h1>
            <p>WIINE er et innovativt convenience tilbud til dig, der ikke vil gå glip af noget. Vi bestræber os på at levere kvalitets rosé til dig, når du har brug for det. Alt du skal gøre er, at afgive en bestilling fra din mobil, og så leverer vores friske bude din rosé, direkte til dig. Velkommen i verden hyggeligtste vinklub, hvor hver dag er rosévejr!   </p>
          </div>

          <div class="col-md-6 grid-V">
            <img src="img/V.png" class="img-responsive" style="max-width: 100%">
          </div>
        </div>
      </div>
    </section>
    <!-- /Vision -->

    <!-- Rosé -->
    <section class="rose" id="rose">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-6 grid-R">
            <img src="img/R.png" class="img-responsive" style="max-width: 100%">
          </div>

          <div class="col-md-6 txt-area">
            <h1>Rosé</h1>
            <p>Vores vin er en syditaliensk rosé af højeste kvalitet.Vi bestræber os levere høj kvalitet, der smager af solskin og lange nætter. Bestil og få leveret din sommer accessory med det samme!</p>
            <!-- Stripe betalingsknap-->
            <div class="container-fluid container_pay">
              <?php require_once('./config.php'); ?>
                <form action="charge.php" method="post">
                  <script src="https://checkout.stripe.com/checkout.js" class="stripe-button"
                  data-key="<?php echo $stripe['publishable_key']; ?>"
                  data-description="Glas"
                  data-amount="5000"
                  data-locale="auto"
                  data-currency="dkk">
                  </script>
                </form>
            </div>
            <!-- /Stripe betalingsknap -->
          </div>
        </div>
      </div>
    </section>
    <!-- /Rosé -->

    <section class="glas" id="glas">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-6 txt-area">
            <h1>Glas</h1>
            <p>Bestil vores gratis pakke med glas når du bestiller vin, og få 5 af vores bæredygtige papglas med ved levering.</p>
            
            <!-- Stripe betalingsknap-->
            <div class="container-fluid container_pay">
              <?php require_once('./config.php'); ?>
                <form action="charge.php" method="post">
                  <script src="https://checkout.stripe.com/checkout.js" class="stripe-button"
                  data-key="<?php echo $stripe['publishable_key']; ?>"
                  data-description="Glas"
                  data-amount="5000"
                  data-locale="auto"
                  data-currency="dkk">
                  </script>
                </form>
            </div>
            <!-- /Stripe betalingsknap -->
          </div>

          <div class="col-md-6 grid-G">
            <img src="img/G.png" class="img-responsive" style="max-width: 100%">
          </div>
        </div>
      </div>
    </section>

    <section class="kontakt" id="kontakt">
      <div class="container-fluid">

        <div class="row">

          <div class="col-md-6 grid-K">
            <img src="img/K.png" class="img-responsive" style="max-width: 100%">
          </div>

          <div class="col-md-6 txt-area">
            <h1>Kontakt</h1>
            <form id="contact-form">
              <div class="form-group">
                <label for="formGroupExampleInput"><p>Navn</p></label>
                <input type="text" class="form-control" id="formGroupExampleInput" >
              </div>
              <div class="form-group">
                <label for="formGroupExampleInput2"><p>Mail</p></label>
                <input type="text" class="form-control" id="formGroupExampleInput2" >
              </div>
              <div class="form-group">
                <label for="formGroupExampleInput2"><p>Besked</p></label>
                <input type="text" class="form-control" id="formGroupExampleInput3" >
              </div>
              <button class="btn btn-outline-secondary" type="submit">Send</button>
            </form>
          </div>

        </div>
      </div>
    </section>

    <section class="footer">
      

    </section>

    <footer class="footer">
      <div class="container-fluid">
        <div class="row">
        <div class="col-6 col-xs">
          <h5>Wiine</h3>
          <a href="#">
          <i class="fab fa-facebook-square fa-4x"></i>
         </a>
         <a href="#" class="SoMe">
          <i class="fab fa-instagram fa-4x"></i>
         </a>
        </div>
        <div class="col-6 col-xs">
          <h5>Handelsbetingelser</h3>
          <ul class="list-unstyled text-small">
            <li><a class="text-muted" href="#">Salgs-& Handelsbetingelser</a></li>
            <li><a class="text-muted" href="#">Persondatapolitik</a></li>
            <li><a class="text-muted" href="#">FAQ</a></li>
          </ul>
        </div>
      </div>

      </div>
      
    </footer>

    


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>
    <script src="firebase.sender.js"></script>
  </body>
</html>