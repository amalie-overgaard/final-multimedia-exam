<?php
require_once('./init.php');

$stripe = array(
  "secret_key"      => "sk_test_uYK6aZZUb9v5SXNgBvwLc3vt",
  "publishable_key" => "pk_test_uXZ34ZBIcATRhv4ElDFUDdZX"
);

\Stripe\Stripe::setApiKey($stripe['secret_key']);
?>