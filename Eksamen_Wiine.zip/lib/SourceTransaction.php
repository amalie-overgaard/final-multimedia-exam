<?php

namespace Stripe;

/**
 * Class SourceTransaction
 *
 * @package Stripe
 */
class SourceTransaction extends ApiResource
{

    const OBJECT_NAME = "source_transaction";
}
