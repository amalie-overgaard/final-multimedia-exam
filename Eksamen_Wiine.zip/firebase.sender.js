var DataBaseName = 'henvendelser';
var database = firebase.database();
var ref = database.ref(DataBaseName);

document.getElementById('contact-form').addEventListener('submit', function (e) {
    e.preventDefault();
    var input1 = getval('formGroupExampleInput'),
    input2 = getval('formGroupExampleInput2'),
    input3 = getval('formGroupExampleInput3');
    // Input id svarer til deres navn, fx input1 = name
    ref.set({
        name: input1,
        email: input2,
        message: input3
    });
});

function getval (id) {
    return document.getElementById(id).value;
}